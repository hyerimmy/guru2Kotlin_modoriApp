package com.example.guruapp

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Login : AppCompatActivity() {

    lateinit var dbManager: DBManager
    lateinit var sqlitedb:SQLiteDatabase

    lateinit var idEdt:EditText
    lateinit var pwdEdt:EditText
    lateinit var loginBtn:Button
    lateinit var regBtn:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        title="Login"

        idEdt=findViewById(R.id.idEdt)
        pwdEdt=findViewById(R.id.pwdEdt)
        loginBtn=findViewById(R.id.loginBtn)
        regBtn=findViewById(R.id.regBtn)

        var str_id =idEdt.text.toString()
        var str_pwd=pwdEdt.text.toString()

        //로그인
        loginBtn.setOnClickListener {
            dbManager= DBManager(this,"study",null,1)
            sqlitedb=dbManager.readableDatabase

            var cursor:Cursor
            cursor=sqlitedb.rawQuery("SELECT * FROM study WHERE id='"+str_id+"';",null)

            if(cursor.moveToNext()){
                if (cursor.getString(cursor.getColumnIndex("password")).toString()== str_pwd) {
                    //val intent=Intent(this,mainpage::class.java)
                    //intent.putExtra("intent_id",str_id)
                    //startActivity(intent)
                }else{
                    Toast.makeText(applicationContext,"비밀번호를 다시 입력하세요.",Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(applicationContext,"존재하지 않는 아이디입니다.",Toast.LENGTH_SHORT).show()
                val intent=Intent(this,mainpage::class.java)
                startActivity(intent)
            }
        }

        //회원가입
        regBtn.setOnClickListener {
            val intent=Intent(this,RegisterActivity::class.java)
            startActivity(intent)
        }

    }
}