package com.example.guruapp

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import com.bumptech.glide.Glide

class mainpage : AppCompatActivity() {

    lateinit var dbManager: DBManager
    lateinit var sqlitedb: SQLiteDatabase
    lateinit var str_id:String
    lateinit var str_image:ByteArray
    lateinit var str_name:String
    lateinit var str_major:String

    lateinit var stdImage:ImageView
    lateinit var stdName:TextView

    lateinit var siteBtn:ImageButton
    lateinit var calBtn:ImageButton
    lateinit var playBtn:ImageButton
    lateinit var telBtn:ImageButton
    lateinit var logout:Button

    //lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainpage)

        title="메인화면"

        stdImage=findViewById(R.id.stdImage)
        stdName=findViewById(R.id.stdName)

        siteBtn=findViewById(R.id.siteBtn)
        calBtn=findViewById(R.id.calBtn)
        playBtn=findViewById(R.id.playBtn)
        telBtn=findViewById(R.id.telBtn)
        logout=findViewById(R.id.logout)

        //toolbar=findViewById(R.id.maintoolbar)
        //setSupportActionBar(toolbar)

//        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
//        supportActionBar!!.setHomeAsUpIndicator(R.drawable.dada)
//        supportActionBar!!.setDisplayShowTitleEnabled(false)

        //이미지로딩
        Glide.with(this).load(R.drawable.site).into(siteBtn)
        Glide.with(this).load(R.drawable.cal).into(calBtn)
        Glide.with(this).load(R.drawable.musicplay).into(playBtn)
        Glide.with(this).load(R.drawable.phonenumber).into(telBtn)

        //프로필 사진,이름,전공
        val intent=intent
        str_id=intent.getStringExtra("intent_id").toString()
        dbManager= DBManager(this,"study",null,1)
        sqlitedb=dbManager.readableDatabase
        var cursor: Cursor
        cursor=sqlitedb.rawQuery("SELECT * FROM study WHERE id='"+str_id+"';",null)

        if (cursor.moveToNext()){
            str_image=cursor.getBlob(cursor.getColumnIndex("image"))
            str_name=cursor.getString(cursor.getColumnIndex("name")).toString()
            str_major=cursor.getString(cursor.getColumnIndex("major")).toString()
        }
        cursor.close()
        sqlitedb.close()
        dbManager.close()

        //이미지
        //stdImage=
        stdName.text=str_name+" | "+str_major

        //버튼 클릭시
        siteBtn.setOnClickListener {
            //val intent=Intent(this,site::class.java)
            //startActivity(intent)
        }

        calBtn.setOnClickListener {
//            val intent=Intent(this,cal::class.java)
//            startActivity(intent)
        }

        playBtn.setOnClickListener {
//            val intent=Intent(this,play::class.java)
//            startActivity(intent)
        }

        telBtn.setOnClickListener {
//            val intent=Intent(this,tel::class.java)
//            startActivity(intent)
        }

        //로그아웃 클릭시
//        logout.setOnClickListener {
//
//        }

    }

}